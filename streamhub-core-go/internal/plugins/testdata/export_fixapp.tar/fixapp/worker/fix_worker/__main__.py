print("hi ñ")
