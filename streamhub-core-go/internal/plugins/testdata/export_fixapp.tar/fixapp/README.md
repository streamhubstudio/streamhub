# Fixture App — standalone worker

> Exported from **StreamHub Studio** as a self-contained app. Run it on your own
> infrastructure and point it back at any StreamHub over HTTPS.

Synthetic exportable worker app for the export vectors.

## What's in here

    fixapp/
      worker/            the Python worker package (source + requirements.txt + tests)
      Dockerfile         python:3.11-slim + requirements + `python -m fix_worker`
      docker-compose.yml one service, reads .env
      .env.example       every setting, as safe placeholders
      README.md          this file
      LICENSE            the project license

## Quickstart

    cp .env.example .env
    # edit .env — set the StreamHub origin, room, and (optionally) your callback
    docker compose up --build

That builds the image and starts the worker. Logs stream to stdout.

## Pointing it at your StreamHub

Point **FIX_PUBLIC_BASE** at your StreamHub origin (e.g.
`https://your-streamhub.example.com`) and leave the `*_HLS_DIR` variable empty — the
worker pulls `/hls/<app>/<room>/index.m3u8` over HTTPS. No shared disk or
loopback is required, so this runs anywhere with network access to your server.

## How it talks back

Set **FIX_CALLBACK_URL** to your HTTPS endpoint and **FIX_CALLBACK_SECRET** to a
shared secret. Every event is POSTed to that URL and signed:

    X-StreamHub-Signature: sha256=<HMAC-SHA256 of the raw request body, hex>

Verify it on your side with the same secret before trusting the payload.

## Configuration

Open `.env.example`: it lists every variable the worker reads, with a comment
on each. Placeholders are safe to commit; your filled-in `.env` is not.

## Extending

The worker is plain Python — edit files under `worker/`, add dependencies to
`worker/requirements.txt`, and rebuild (`docker compose up --build`). Its tests
live in `worker/tests` (`pytest`).

## License

See `LICENSE`. StreamHub components are AGPL-3.0-only unless noted otherwise in
the worker's own README.
